import { mdxAnnotations } from 'mdx-annotations'

export const remarkPlugins = [mdxAnnotations.remark]
